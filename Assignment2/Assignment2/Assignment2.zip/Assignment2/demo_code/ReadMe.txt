Version: Node v8.9.4 OS:windows 10 pro 64-bit

Install: There is no need to install any needed code.

Launch:
command window: node server.js

Testing/URL link:
http://localhost:3000/assignment2.html