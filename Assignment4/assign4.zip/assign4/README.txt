Version: Node v8.9.4 OS:windows 10 pro 64-bit

Install: 
>express: ^4.15.3
>request: ^2.81.0
>serve-favicon: ^2.4.5
>pug: ^2.0.3 (i just installed to play with :p)
>npm install

Launch:
>node server.js


To see the "app" version use your browser to visit:
http://localhost:3000
http://localhost:3000/
http://localhost:3000/index.html
http://localhost:3000/recipes
http://localhost:3000/recipes.html